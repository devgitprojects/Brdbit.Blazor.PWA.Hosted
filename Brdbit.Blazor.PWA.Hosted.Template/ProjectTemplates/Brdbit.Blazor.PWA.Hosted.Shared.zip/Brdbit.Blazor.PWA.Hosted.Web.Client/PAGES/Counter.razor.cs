namespace $safeprojectname$.Pages;
/// <summary>
/// 3333
/// </summary>
public partial class Counter
{
    private int currentCount = 0;

    private void IncrementCount()
    {
        currentCount++;
    }
}