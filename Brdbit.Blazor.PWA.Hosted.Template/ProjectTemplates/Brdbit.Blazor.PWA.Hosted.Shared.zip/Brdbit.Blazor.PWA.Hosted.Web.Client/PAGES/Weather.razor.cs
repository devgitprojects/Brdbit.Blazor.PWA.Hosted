using System.Net.Http.Json;

using $ext_safeprojectname$.Shared;

using Microsoft.AspNetCore.Components;

namespace $safeprojectname$.Pages;

public partial class Weather
{
    private WeatherForecast[]? forecasts;

    [Inject] 
    public HttpClient Http { get; set; } = default!;

    protected override async Task OnInitializedAsync()
    {
        forecasts = await Http.GetFromJsonAsync<WeatherForecast[]>("/weatherforecast");
    }
}